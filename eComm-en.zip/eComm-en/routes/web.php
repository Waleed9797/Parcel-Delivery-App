<?php

use Illuminate\Support\Facades\Route;
// 3. importing the user controller 
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;


// Reference 
// https://www.youtube.com/watch?v=rGQSqCJFQiI&list=PL8p2I9GklV47EWeJZlC-_dgj7kdBWYd56
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/login', function () {
    return view('Login');
});

// 8. this is for the logout, once the user is loged out it will take them to the login page
Route::get('/logout', function () {
    
    Session::forget('user');
    return redirect('login');
});
// 11.this routee for the register button 
Route::view('/register', 'register');
Route::post("/register",[UserController::class,'register']);
// 3. this route is for the user controller 
// 3. for the post request the login route is used to open the login on the login page 
// http://127.0.0.1:8000/login 
Route::post("/login",[UserController::class,'login']);
Route::get("/",[ProductController::class,'index']);
// THis is for the product details 
Route::get("detail/{id}",[ProductController::class,'detail']);
// 7. THis route is for searching products
Route::get("search",[ProductController::class,'search']);
// 7. THis route is for add to cartt pagee
Route::post("add_to_cart",[ProductController::class,'addToCart']);
// 9. THis route is for cartt listt pagee
Route::get("cartlist",[ProductController::class,'cartList']); 
// 9. THis route is to remove product in the cart pagee
Route::get("removecart/{id}",[ProductController::class,'removeCart']); 
Route::get("ordernow",[ProductController::class,'orderNow']); 
Route::post("orderplace",[ProductController::class,'orderPlace']);
Route::get("myorders",[ProductController::class,'myOrders']);



