<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
// 2. importing the database file 
use Illuminate\Support\Facades\DB;
// 2. Hash is used to encrypt the password 
use Illuminate\Support\Facades\Hash;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //2. Adding data to the database
        DB::table('users')->insert([
            'name'=>'Waleed Fathli',
            'email'=>'Waleed@Fathli.com',
            'password'=>Hash::make('12345')
        ]);
    }
}