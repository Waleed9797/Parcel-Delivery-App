@extends('master')
@section("content")
<div class="container">
<div class="row">
       <div class="col-sm-6">
       <!-- 6. this is to print the image of the product in a sprate page  -->
       <!-- 6. classs is used to reduce the size of the image  -->
       <img class="detail-img" src="{{$product['gallery']}}" alt="">
       </div>

        <!-- 6. details of the product  -->
       <div class="col-sm-6">
            <!-- 6. this is a go back link -->
           <a href="/">Go Back</a>
       <h2>{{$product['name']}}</h2>
       <h3>Price : {{$product['price']}}</h3>
       <h4>Details: {{$product['description']}}</h4>
       <h4>category: {{$product['category']}}</h4>
       <br><br>
       <!-- this is the product id  -->
       <form action="/add_to_cart" method="POST">
           @csrf
           <input type="hidden" name="product_id" value={{$product['id']}}>
        <!-- 6. this is add to cart button in the product details  -->
       <button class="btn btn-primary">Add to Cart</button>
       </form>
       <br><br>
        <!-- 6. this is buy now button in the product details  -->
       <button class="btn btn-success">Buy Now</button>
       <br><br>
    </div>
</div>
</div>

@endsection