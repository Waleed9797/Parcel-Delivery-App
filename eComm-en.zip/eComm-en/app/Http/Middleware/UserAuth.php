<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class UserAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
    // 3. this is used to delete the login from the link if the user is already loged in 
        if($request->path()=="login" && $request->session()->has('user'))
        {
            // 3.this will redirect the user to the home page 
            return redirect('/');
        }
        return $next($request);
    }
}

