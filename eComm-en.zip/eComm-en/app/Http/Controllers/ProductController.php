<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;

use Session;
use Illuminate\Support\Facades\DB;
class ProductController extends Controller
{
    function index()
    {
        // 4. this is to get all data from product table 
        $data= Product::all();
        // 4. this is to pass the data to view 
        return view('product',['products'=>$data]);

    }
    // 6. this function is for the product details by id
    function detail($id)
    {   
        // 6this will get the data by id form the db
        $data =Product::find($id);
        return view('detail',['product'=>$data]);
    }
    // 7. this function is for searching the product 
    function search(Request $req)
    {
        $data= Product::
        where('name', 'like', '%'.$req->input('query').'%')
        ->get();
        return view('search',['products'=>$data]);
    }
    // 7. we use this request wheneever we need data from the form in the http
    function addToCart(Request $req)
    {
        // 7. this to check if the user is loged in then he can go to the cart page, if not he will be redirect to the home page 
        if($req->session()->has('user'))
        {
            $cart= new Cart;
           $cart->user_id=$req->session()->get('user')['id'];
           $cart->product_id=$req->product_id;
           $cart->save();
           return redirect('/');

        }
        // 7. else is redirect the user to login page
        else
        {
            return redirect('/login');
        }
}
        // 8. this functionn is to get cart item 
        static function cartItem()
        {
        $userId=Session::get('user')['id'];
        return Cart::where('user_id',$userId)->count();
        }
        // 9. this functionn is for the cartt listt
        function cartList()
        {
            $userId=Session::get('user')['id'];
            // 8.this is the cartt model.
               $products= DB::table('cart')
            ->join('products','cart.product_id','=','products.id')
            ->where('cart.user_id',$userId)
            ->select('products.*','cart.id as cart_id')
            ->get();
    
            return view('cartlist',['products'=>$products]);
        }

        function removeCart($id)
        {
            Cart::destroy($id);
            return redirect('cartlist');
        }
        // 10. this functionn is for the order now button
        function orderNow()
        {
            $userId=Session::get('user')['id'];
            $total= $products= DB::table('cart')
             ->join('products','cart.product_id','=','products.id')
             ->where('cart.user_id',$userId)
             ->sum('products.price');
     
             return view('ordernow',['total'=>$total]);
        }
        // 10.this functionn will accept the dataa from a formm req
        function orderPlace(Request $req)
        {
            $userId=Session::get('user')['id'];
             $allCart= Cart::where('user_id',$userId)->get();
             foreach($allCart as $cart)
             {
                 $order= new Order;
                 $order->product_id=$cart['product_id'];
                 $order->user_id=$cart['user_id'];
                 $order->status="pending";
                 $order->payment_method=$req->payment;
                 $order->payment_status="pending";
                 $order->address=$req->address;
                 $order->save();
                //  this is to remove the data from the cart
                 Cart::where('user_id',$userId)->delete(); 
             }
             $req->input();
             return redirect('/');
        }
        
        function myOrders()
        {
            $userId=Session::get('user')['id'];
            $orders= DB::table('orders')
             ->join('products','orders.product_id','=','products.id')
             ->where('orders.user_id',$userId)
             ->get();
     
             return view('myorders',['orders'=>$orders]);
        }
}
